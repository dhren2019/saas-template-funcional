"use client";

import React, { useState } from "react";
import Templates from "Templates"; // Ajusta la ruta según corresponda
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectItem } from "@/components/ui/select";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

const HeroPage = () => {
  const [formData, setFormData] = useState({});
  const template = Templates.find((t) => t.slug === "seo-optimization");

  if (!template) {
    return <div>Template not found</div>;
  }

  const handleChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Data Submitted:", formData);
    // Lógica para enviar datos al backend
  };

  return (
    <div className="max-w-4xl mx-auto mt-10 p-6">
      <Card>
        <CardHeader>
          <CardTitle>{template.name}</CardTitle>
          <p className="text-gray-600">{template.desc}</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {template.form.map((field, index) => (
              <div key={index} className="space-y-2">
                <label className="block font-medium">{field.label}</label>
                {field.field === "input" && (
                  <Input
                    type="text"
                    placeholder={field.placeholder || ""}
                    required={field.required}
                    onChange={(e) =>
                      handleChange(field.name, e.target.value)
                    }
                  />
                )}
                {field.field === "textarea" && (
                  <Textarea
                    placeholder={field.placeholder || ""}
                    required={field.required}
                    onChange={(e) =>
                      handleChange(field.name, e.target.value)
                    }
                  />
                )}
                {field.field === "select" && (
                  <Select
                    onValueChange={(value) =>
                      handleChange(field.name, value)
                    }
                    required={field.required}
                  >
                    {field.options.map((option, idx) => (
                      <SelectItem key={idx} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </Select>
                )}
              </div>
            ))}
            <Button type="submit" variant="default" className="w-full">
              Submit
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default HeroPage;
