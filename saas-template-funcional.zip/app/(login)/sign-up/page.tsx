import { Login } from '../login';

export default function SignUpPage() {
  return <Login mode="signup" />;
}
