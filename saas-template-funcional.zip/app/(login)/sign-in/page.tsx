import { Login } from '../login';

export default function SignInPage() {
  return <Login mode="signin" />;
}
